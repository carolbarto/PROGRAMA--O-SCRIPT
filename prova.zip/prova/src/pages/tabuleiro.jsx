import CompTabuleiro from "@/components/CompTabuleiro"

export default function ProvaTabuleiro(){
    return(
        <>
            <CompTabuleiro/>
            <CompTabuleiro/>
            <CompTabuleiro/>
            <CompTabuleiro/>
        </>
    )
}